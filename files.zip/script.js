const P=[
["200","Schuler pneumatic","1","1000 x 780 mm","420 mm","200 mm"],
["160","Godrej pneumatic","2","900 x 560 mm","350 mm","120 mm"],
["100","Godrej pneumatic","3","800 x 500 mm","450 mm","110 mm"],
["100","Godrej mechanical","1","800 x 500 mm","450 mm","100 mm"],
["50","Godrej mechanical","2","630 x 400 mm","300 mm","75 mm"]];
const rows=document.getElementById('rows'),panel=document.getElementById('panel');
function show(i){const p=P[i];
[...rows.children].forEach((r,j)=>r.setAttribute('aria-pressed',j===i));
panel.innerHTML=`<h3>${p[0]} ton ${p[1]}</h3><span class="n">${p[2]} in the shop</span><dl><dt>Bed size</dt><dd>${p[3]}</dd><dt>Shut height</dt><dd>${p[4]}</dd><dt>Shut travel</dt><dd>${p[5]}</dd></dl>`}
P.forEach((p,i)=>{const b=document.createElement('button');b.className='row';b.type='button';b.setAttribute('aria-pressed','false');
b.innerHTML=`<span class="t">${p[0]}<small> TON x${p[2]}</small></span><span class="bar"><i style="--w:${p[0]/2}%"></i></span>`;
b.onclick=()=>show(i);rows.appendChild(b)});
show(0);
new IntersectionObserver((e,o)=>e.forEach(x=>{if(x.isIntersecting){rows.classList.add('on');o.disconnect()}}),{threshold:.3}).observe(rows);
const C=["Rajsriya Automotive Pvt Ltd","Kay Pee Eff Tool Tech Pvt Ltd","Izon Industries","SMP Engineering & Electricals Pvt Ltd","Balaji Press Products India Pvt Ltd","AVMS Metal Parts"];
document.getElementById('cg').innerHTML=C.map(c=>{const w=c.replace(/&/g,'').split(' ').filter(Boolean);return `<div class="cc"><div class="mono" aria-hidden="true">${(w[0][0]+w[1][0]).toUpperCase()}</div><b>${c}</b><span>Customer</span></div>`}).join('');
